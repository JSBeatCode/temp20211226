// #11
const { ApolloServer, gql, UserInputError } = require('apollo-server');
// #12
const { nanoid } = require('nanoid');
// #15
const mongoose = require('mongoose');
const { Character, validateCharacter } = require('./models/Characters');
// #22
const jwt = require('jsonwebtoken');
const { User, validateUser } = require('./models/User');

// #18
const Joi = require('@hapi/joi');
mongoose.connect('mongodb://localhost:27017/mydbname', {useNewUrlParser: true})
// #20
const fs = require('fs');
const path = require('path');
// #22
const bcrypt = require('bcrypt');
// #23
const lodash = require('lodash');
// #24 dotenv
require('dotenv').config()
// #25
const {sendConfirmationEmail} = require('./services/EmailService');
const Query = require('./Query');
const Mutation = require('./Mutation');
// const typeDefs = gql`
//     type Character {
//         id: ID
//         name: String!
//         status: String!
//         species: String
//         gender: String
//         image: String
//     }

//     type Query {
//         characters: [Character]
//         character(id: ID!): Character
//     }
//     type Mutation {
//         addCharacter(name: String!, status: String!, species: String, gender: String, image: String): Character
//     }
// `;

// const data = [
//     {
//         id: 1,
//         name: "Random Name"
//     },
//     {
//         id: 2,
//         name: "Another Random Name"
//     },
// ]

// const data = require('./data')


const resolvers = {
    Query,
    Mutation

    // Query: {
    //     // characters: () => data,
    //     characters: async () => 
    //     {
    //         console.log('debug1')
    //         return Character.find({})
    //     },
    //     // 아랫것은 싱크가 안맞아서 주석처리하고 위엣것으로 코딩
    //     // Character.find({}, (error, characters)=>{
    //     //     if(error){
    //     //         console.log('error', error)
    //     //     }
    //     //     return characters
    //     // }),
    //     // character: (_, {id}) => {
    //     //     return data.find( character => character.id == id)
    //     // }
    //     character: async (_, {id}) => 
    //     {
    //         console.log('debug2')
    //         return Character.findById(id)
    //     }
    //     // 아랫것은 싱크가 안맞아서 주석처리하고 위엣것으로 코딩
    //     // Character.findById({}, (error, character)=>{
    //     //     if(error){
    //     //         console.log('error', error)
    //     //     }
    //     //     return character
    //     // })
    // },
    
    // Mutation: {
    //     addCharacter(_, 
    //         // #14 
    //         // {name, status, gender, image}
    //         payload)
    //         {
    //             // #18
    //             // const schema = Joi.object({
    //             //      name: Joi.string().alphanum().min(3).max(30).required(),
    //             //      status: Joi.string().required(),
    //             //      species: Joi.string().allow(''),
    //             //      gender: Joi.string().allow(''),
    //             //      image: Joi.string().allow('')
    //             // });
    //             const {value, error}  = validateCharacter(payload, { abortEarly: false })
    //             // #19
    //             if(error){
    //                 throw new UserInputError('Failed to create a character due to validation errors', {
    //                     validationErrors: error.details
    //                 });
    //             }
    //         // const storeCharacter = {
    //         //     // #12
    //         //     id: nanoid(),
    //         //     // #14 
    //         //     ...payload
    //         //     // name,
    //         //     // status,
    //         //     // gender,
    //         //     // image
    //         // }
    //         // #15
    //         // return Character.create(payload)
    //         // #18
    //         return Character.create(value)
    //         // data.push(storeCharacter)
    //         // return storeCharacter
    //     },
    //     async signup(_, {user}){
    //         const { value, error } = validateUser(user)
    //         if(error){
    //             throw new UserInputError('Failed to create a character due to validation errors', {
    //                 validationErrors: error.details
    //             });
    //         }
    //         // #21 
    //         const password = await bcrypt.hash(user.password, 10);
    //         const registerUser = await User.create({
    //             ...value,
    //             password
    //         })
    //         // #25
    //         await sendConfirmationEmail(registerUser)
    //         // #22
    //         const token = await jwt.sign({
    //             _id: registerUser._id
    //         },
    //         // #23
    //         process.env.JWT_SECRET_KEY
    //         )
    //         return {
    //             token,
    //             // #23
    //             user: lodash.pick(user, ['id', 'name', 'email'])
    //         }
    //     },
    //     async confirmEmail(_, {token}) {
    //         try{
    //             // #22
    //             const verifyToken = jwt.verify(token, process.env.JWT_SECRET_KEY);
    //             console.log('jsdno0 debug2', verifyToken);
    //             return true; 
    //         } catch(err) {
    //             return false;
    //         }
    //     }
    // }
}

const server = new ApolloServer({
    // typeDefs: typeDefs,
    // resolvers: resolvers,
    // #20
    typeDefs: fs.readFileSync(path.join(__dirname, 'schema.graphql'), 'utf-8'),
    resolvers
})
server.listen().then(({ url })=> {
    console.log('Server is running on ' + url)
})
