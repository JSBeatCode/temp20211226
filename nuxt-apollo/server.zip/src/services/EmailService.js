// #22
const jwt = require('jsonwebtoken');
// #25
const nodemailer = require('nodemailer');
const nodemailerSendgrid = require('nodemailer-sendgrid');

const transport = nodemailer.createTransport(
    nodemailerSendgrid({
        apiKey: process.env.SENDGRID_API_KEY
    })
);



const sendConfirmationEmail = async (user) => {
    // #22
    const token = await jwt.sign({
        _id: user._id
    }, process.env.JWT_SECRET_KEY);
    const url = `http://localhost:3000/confirmation/${token}`
    transport.sendMail({
        from:'csdnum0@gmail.com',
        to: `${user.name} <${user.email}>`,
        subject: 'Confirmation Email',
        html: `Confirmation Email <a href=${url}>${url}</a>`
    }).then(()=>{
        alert('email has been sent')
    }).catch(()=>{
        alert('email send error')
    });
}

exports.sendConfirmationEmail = sendConfirmationEmail;
