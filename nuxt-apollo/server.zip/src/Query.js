const { Character } = require("./models/Characters");

const Query = {
    // characters: () => data,
    characters: async () => 
    {
        return Character.find({})
    },
    // 아랫것은 싱크가 안맞아서 주석처리하고 위엣것으로 코딩
    // Character.find({}, (error, characters)=>{
    //     if(error){
    //         console.log('error', error)
    //     }
    //     return characters
    // }),
    // character: (_, {id}) => {
    //     return data.find( character => character.id == id)
    // }
    character: async (_, {id}) => 
    {
        return Character.findById(id)
    }
    // 아랫것은 싱크가 안맞아서 주석처리하고 위엣것으로 코딩
    // Character.findById({}, (error, character)=>{
    //     if(error){
    //         console.log('error', error)
    //     }
    //     return character
    // })
}

module.exports = Query;