// #15
const mongoose = require('mongoose');

const Joi = require('@hapi/joi');

const schema = new mongoose.Schema({
    // name: String,
    name: {
        type: String,
        required: true,
        minlength: 1,
        maxlength: 50,
    },
    // status: String,
    email: {
        type: String,
        required: true,
        minlength: 1,
        maxlength: 255,
        unique: true,
    },
    password: {
        type: String,
        required: true,
        minlength: 5,
        maxlength: 1024,
    },
    emailVerified: {
        type: Boolean,
        default: false,
    }
})

const User = mongoose.model('User', schema)

const validateUser = (user) =>{
    return Joi.object({
        name: Joi.string().alphanum().min(1).max(50).required(),
        email: Joi.string().required().email(),
        password: Joi.string().min(5).max(1024).required(),
   }).validate(user)
}

// module.exports = Character;
exports.User = User;
exports.validateUser = validateUser;

