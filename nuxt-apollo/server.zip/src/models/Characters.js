// #15
const mongoose = require('mongoose');

const Joi = require('@hapi/joi');

const schema = new mongoose.Schema({
    // name: String,
    name: {
        type: String,
        required: true
    },
    // status: String,
    status: {
        type: String,
        required: true
    },
    species: String,
    gender: String,
    image: String
})

const Character = mongoose.model('Character', schema)

const validateCharacter = (character) =>{
    return Joi.object({
        name: Joi.string().alphanum().min(3).max(30).required(),
        status: Joi.string().required(),
        species: Joi.string().allow(''),
        gender: Joi.string().allow(''),
        image: Joi.string().allow('')
   }).validate(character)

   
}

// module.exports = Character;
exports.Character = Character;
exports.validateCharacter = validateCharacter;

