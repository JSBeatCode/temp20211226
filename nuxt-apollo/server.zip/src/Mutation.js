const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const lodash = require('lodash');
const { UserInputError } = require("apollo-server-errors")
const { Character, validateCharacter } = require("./models/Characters")
const { User, validateUser } = require("./models/User")
const { sendConfirmationEmail } = require("./services/EmailService")

const Mutation = {
    addCharacter(_, 
        // #14 
        // {name, status, gender, image}
        payload)
        {
            // #18
            // const schema = Joi.object({
            //      name: Joi.string().alphanum().min(3).max(30).required(),
            //      status: Joi.string().required(),
            //      species: Joi.string().allow(''),
            //      gender: Joi.string().allow(''),
            //      image: Joi.string().allow('')
            // });
            const {value, error}  = validateCharacter(payload, { abortEarly: false })
            // #19
            if(error){
                throw new UserInputError('Failed to create a character due to validation errors', {
                    validationErrors: error.details
                });
            }
        // const storeCharacter = {
        //     // #12
        //     id: nanoid(),
        //     // #14 
        //     ...payload
        //     // name,
        //     // status,
        //     // gender,
        //     // image
        // }
        // #15
        // return Character.create(payload)
        // #18
        return Character.create(value)
        // data.push(storeCharacter)
        // return storeCharacter
    },
    async signup(_, {user}){
        const { value, error } = validateUser(user)
        if(error){
            throw new UserInputError('Failed to create a character due to validation errors', {
                validationErrors: error.details
            });
        }
        // #21 
        const password = await bcrypt.hash(user.password, 10);
        const registerUser = await User.create({
            ...value,
            password
        })
        // #25
        await sendConfirmationEmail(registerUser)
        // #22
        const token = await jwt.sign({
            _id: registerUser._id
        },
        // #23
        process.env.JWT_SECRET_KEY
        )
        return {
            token,
            // #23
            user: lodash.pick(user, ['id', 'name', 'email'])
        }
    },
    async confirmEmail(_, {token}) {
        try{
            // #22
            // const verifyToken = jwt.verify(token, process.env.JWT_SECRET_KEY);
            // console.log('jsdno0 debug2', verifyToken);
            const {_id} = jwt.verify(token, process.env.JWT_SECRET_KEY);
            const user = await User.findById(_id);
            user.emailVerified = true;
            user.save();
            return true; 
        } catch(err) {
            return false;
        }
    }
}

module.exports = Mutation;